package ca.mcgill.ecse211.finalProject;
/**
 * this class is used to measure the weight of the can 
 * @author jacobmcconnell
 *
 */
public class WeightMeasurment {
  
  /**
   * this method checks if can is heavy 
   * @return if can is heavy or not
   */
  public static boolean isHeavy(){
    return false; 
    
  }
  /**
   * this is used to calibrate the weight measurment system it will find the initial angle then it will turn a set amount of time 
   * then it will find the final angle it returns the difference in angles. 
   * @return the difference between intiial and final angle 
   */
  public static double numericalWeight() {
    // need to implement 
    return 1;
    
  }

}
