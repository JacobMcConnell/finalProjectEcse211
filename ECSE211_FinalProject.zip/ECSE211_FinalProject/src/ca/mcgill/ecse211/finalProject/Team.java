package ca.mcgill.ecse211.finalProject;
/** 
 * Enumeration for the Team's color  
 * 
 * @author Erdong Luo
 */
public enum Team {
	RED, GREEN
}
